//28. Convert years into days and months.

#include<stdio.h>
main() 

{
    int years, total_days, months, days;

    printf("\n\t Enter the number of years : ");
    scanf("%d", &years);
    printf("\n----------------------------------------------------------\n");

    total_days = years * 365;     // Convert years to total days

    months = total_days / 30.45;     // Convert total days to months and remaining days
    days = total_days - (months * 30.45);

    printf("\n\t --> | %d years | is approximately | %d months | & | %d days | \n", years, months, days);
}

