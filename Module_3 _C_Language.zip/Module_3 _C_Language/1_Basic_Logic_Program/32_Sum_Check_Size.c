//32. Accept 2 numbers and find out its sum check it size.

#include <stdio.h>
main()

{
    int num1, num2, sum;
    
    printf("\n\t Enter first number : ");
    scanf("%d", &num1);
    printf("\n\t Enter second number : ");
    scanf("%d", &num2);
    printf("\n------------------------------------------------------------------------------------------\n");
    
    sum=num1+num2;     // Calculate the sum

    printf("\n\t Sum = num1+num2");
    printf("\n\t Sum = | %d | \n", sum);
    printf("\n------------------------------------------------------------------------------------------\n");
    
    printf("\n\t --> Size of sum in bytes : | %u  |\n", sizeof(sum));     // Determine the size of the sum in bytes
    printf("\n------------------------------------------------------------------------------------------\n");
}

