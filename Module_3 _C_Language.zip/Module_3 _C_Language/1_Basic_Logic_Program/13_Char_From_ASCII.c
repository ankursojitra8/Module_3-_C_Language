//13. Find character value from ASCII.

#include<stdio.h>
main()

{
    int ascii_code;

    /*Input ASCII code from user
    Uppercase alphabet characters in ASCII have values ranging from 65 to 90
    Lowercase alphabet characters in ASCII have values ranging from 97 to 122
    */
    printf("\n\t Enter ASCII code (between 0 and 127): ");
    scanf("%d", &ascii_code);
    printf("\n---------------------------------------------------------");

    char character=(char)ascii_code;     // Convert ASCII code to character

    printf("\n\t --> Character corresponding to ASCII code { %d } is : | %c |    \n", ascii_code, character);
}

