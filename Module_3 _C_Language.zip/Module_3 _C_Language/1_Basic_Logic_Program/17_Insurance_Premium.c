//17. Calculate person's insurance premium based on salary.

#include<stdio.h>
main()

{
    float salary, premium, premium_rate;

    printf("\n\t Enter the person's salary: ");
    scanf("%f", &salary);

    
    if (salary<30000)      // Define the premium rate based on salary ranges
        premium_rate=0.05;  // 5% of the salary

	else if (salary<60000)
        premium_rate=0.10;  // 10% of the salary

	else if (salary<90000) 
        premium_rate=0.15;  // 15% of the salary
        
	else 
        premium_rate=0.20;  // 20% of the salary

    premium=salary*premium_rate;     // Calculate the premium

    printf("\n\t --> The insurance premium is: %.2f\n", premium);
}

