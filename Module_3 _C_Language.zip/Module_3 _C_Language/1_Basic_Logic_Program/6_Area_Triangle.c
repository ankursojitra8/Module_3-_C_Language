//6. Find area of Triangle Formula : A = 1/2 � b � h.

#include<stdio.h>
main()

{
    float base, height, area;

    printf("\n\t Enter the base of the triangle: ");
    scanf("%f", &base);
    printf("\n\t Enter the height of the triangle: ");
    scanf("%f", &height);
    printf("\n---------------------------------------------------------");


    area=0.5*base*height;     // Calculate the area of the triangle

    printf("\n\t --> Area of the triangle: %.2f\n", area);
}

