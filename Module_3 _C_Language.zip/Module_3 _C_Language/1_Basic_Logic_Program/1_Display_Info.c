/*1. Display This Information using printf.

1.	Your Name 
2.	Your Birth date 
3.	Your Age 
4.	Your Address 
*/

#include <stdio.h>
main() 

{
    char name[15] = "Ankur Sojitra";
    char birthDate[18] = "11 August 2000";
    int age = 24;
    char address[65] = "Ahemdabad, Gujarat";
    
    printf("\n\t 1.) Your Name: %s\n", name);
    printf("\n\t 2.) Your Birth date: %s\n", birthDate);
    printf("\n\t 3.) Your Age: %d\n", age);
    printf("\n\t 4.) Your Address: %s\n", address);
}

