//31. Convert kilometres into meters.

#include<stdio.h>
main() 

{
    float kilometers, meters;

    printf("\n\t Enter distance in kilometers: ");
    scanf("%f", &kilometers);
    printf("\n------------------------------------------------------------------------------------------\n");

    meters=kilometers*1000;     // Convert kilometers to meters

    printf("\n\t --> Convert kilometers to meters : ");
    printf("| %.2f kilometers | is equal to | %.2f meters | \n", kilometers, meters);
    printf("\n------------------------------------------------------------------------------------------\n");
}

