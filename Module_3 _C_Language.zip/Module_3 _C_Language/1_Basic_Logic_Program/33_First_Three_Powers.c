//33. C Program to Read Integer and Print First Three Powers (N^1, N^2, N^3).

#include <stdio.h>
main() 

{
    int num;
    
    printf("\n\t Enter an integer : ");
    scanf("%d", &num);
    printf("\n-----------------------------------------\n");
    printf("-----------------------------------------\n");
    
    printf("\n\t --> First power (%d^1) : %d \n", num, num);     // Calculate and print powers
    printf("\n-----------------------------------------\n");
    printf("\n\t --> Second power (%d^2) : %d \n", num, num * num);
    printf("\n-----------------------------------------\n");
    printf("\n\t --> Third power (%d^3) : %d \n", num, num * num * num);
    printf("\n-----------------------------------------\n");
}

