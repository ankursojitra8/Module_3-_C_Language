//11. Find circumference of square formula : C = 4 * a.

#include<stdio.h>
main()

{
    float side, perimeter;

    printf("\n\t Enter the side length of the square: ");
    scanf("%f", &side);

    perimeter=4*side;     // Calculate the perimeter of the square

    printf("\n\t --> Perimeter of the square: %.2f\n", perimeter);
}

