//12. Accept number of students from user. I need to give 5 apples to each student. How many apples are required?

#include<stdio.h>
main()

{
    int num_students, apples_per_student = 5, total_apples_needed;

    printf("\n\t Enter the number of students : ");
    scanf("%d", &num_students);

    total_apples_needed=num_students*apples_per_student;     // Calculate total apples needed

    printf("\n\t --> Total apples required: %d\n", total_apples_needed);
}

