//16. Convert country's name in abbreviate form.

#include<stdio.h>
main()

{
	char country[30]="India";
	
	printf("\n\n\t %s", country);	
	
	printf("\n\n\t --> Abbreviation : %c ",country[0]);
}
