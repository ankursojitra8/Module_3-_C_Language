//14. Find ASCII value of given number.

#include<stdio.h>
main()

{
    char character;
    int ascii_value;

    printf("\n\t Enter a character: ");
    scanf(" %s", &character);
    printf("\n---------------------------------------------------------");


    ascii_value=(char)character;     // Convert character to ASCII value

    printf("\n\t --> ASCII value of '%c' is: | %d | \n", character, ascii_value);
}

