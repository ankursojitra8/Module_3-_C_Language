/* 22_2. Calculate compound interest (Compound Interest formula:
b.
Compound Interest = Amount � P
*/
#include <stdio.h>
main() 
{
    double principal, rate, time, amount, compound_interest;

    printf("\n\t Enter the principal amount : ");
    scanf("%lf", &principal);

    printf("\n\t Enter the annual interest rate (in percentage) : ");
    scanf("%lf", &rate);

    printf("\n\t Enter the time period (in years) : ");
    scanf("%lf", &time);
    printf("\n----------------------------------------------------------------");

    amount=principal*pow((1+rate/100), time);     // Calculate amount using compound interest formula

    compound_interest=amount-principal;     // Calculate compound interest

    printf("\n\t --> Compound Interest: %.2lf \n", compound_interest);
    printf("\n\t --> Total Amount: %.2lf \n", amount);
}

