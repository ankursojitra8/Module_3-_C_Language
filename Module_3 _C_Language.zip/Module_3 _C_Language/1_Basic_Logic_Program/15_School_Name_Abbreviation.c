//15. Convert school's name in abbreviated form.

#include<stdio.h>
main()

{
	char name[30]="School's";
	
	printf("\n\n\t %s", name);
	
	printf("\n\n\t Abbreviation : %c . %c", name[0], name[7]);
}
