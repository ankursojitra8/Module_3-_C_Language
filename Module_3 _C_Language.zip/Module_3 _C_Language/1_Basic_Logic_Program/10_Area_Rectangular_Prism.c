//10. find the area of a rectangular prism formula : A=2(wl+hl+hw).

#include<stdio.h>
main()

{
    float width, length, height, surface_area;

    printf("\n\t Enter the width of the rectangular prism: ");
    scanf("%f", &width);
    printf("\n\t Enter the length of the rectangular prism: ");
    scanf("%f", &length);
    printf("\n\t Enter the height of the rectangular prism: ");
    scanf("%f", &height);
    printf("\n--------------------------------------------------------------");

    surface_area=2*(width*length+height*length+height*width);     // Calculate the surface area of the rectangular prism

    printf("\n\t --> Surface area of the rectangular prism: %.2f\n", surface_area);
}

