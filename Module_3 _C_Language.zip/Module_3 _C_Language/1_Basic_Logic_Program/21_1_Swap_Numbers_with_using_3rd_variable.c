// 21_1. Accept 2 numbers from user and swap 2 numbers with using 3rd variable

#include<stdio.h>
main()

{
    int num1, num2, temp;

    printf("\n\t Enter first number: ");
    scanf("%d", &num1);
    printf("\n\t Enter second number: ");
    scanf("%d", &num2);
    printf("\n---------------------------------------------------------------------");

    printf("\n\n\t *** Original numbers: num1 = %d, num2 = %d *** \n", num1, num2);
    printf("\n---------------------------------------------------------------------\n");

    temp=num1;     // Swap using a third variable
    num1=num2;
    num2=temp;

    printf("\n\n\t --> Swapped numbers using third variable: num1 = %d, num2 = %d \n\n", num1, num2);
}


