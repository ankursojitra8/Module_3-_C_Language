//4. Find Area of Square formula : a = a2.

#include<stdio.h>
main()

{
    float side, area;

    printf("\n\t Enter the side length of the square: ");
    scanf("%f", &side);

    area=side*side;     // Calc. the area of the square

    printf("\n\t --> Area of the square: %.2f\n", area);
}

