/*
2. Write a program to make Simple calculator.
to make addition, subtraction, multiplication, division and modulo) 
*/
#include<stdio.h>
main() 

{
    int num1, num2;
    char operator;
    int result;

    printf("\n*Simple Calculator*\n");
    printf("\n  Available operations:\n");
    printf("\n\t 1. Addition (+)\n");
    printf("\n\t 2. Subtraction (-)\n");
    printf("\n\t 3. Multiplication (*)\n");
    printf("\n\t 4. Division (/)\n");
    printf("\n\t 5. Modulo (%%)\n");

    printf("\n 1)                 Enter first number : ");
    scanf("%d", &num1);
    printf("\n  ) Enter an operator (+, -, *, /, %%) : ");
    scanf(" %c", &operator);
    printf("\n 2)                Enter second number : ");
    scanf("%d", &num2);
    printf("\n-----------------------------------------------------------");
    printf("\n-----------------------------------------------------------");

    switch (operator)     // Perform the selected operation
	{
        case '+':
            result = num1 + num2;
            printf("\n\t --> Result: %d + %d = %d\n", num1, num2, result);
            break;
        case '-':
            result = num1 - num2;
            printf("\n\t --> Result: %d - %d = %d\n", num1, num2, result);
            break;
        case '*':
            result = num1 * num2;
            printf("\n\t --> Result: %d * %d = %d\n", num1, num2, result);
            break;
        case '/':
            if (num2 != 0) 
			{
                result = num1 / num2;
                printf("\n\t --> Result: %d / %d = %d\n", num1, num2, result);
            } 
			else 
			{
                printf("\n\t --> ***Error: Division by zero is not allowed.***\n");
            }
            break;
        case '%':
            if (num2 != 0) 
			{
                result = num1 % num2;
                printf("\n\t --> Result: %d %% %d = %d\n", num1, num2, result);
            } else 
			{
                printf("\n\t --> ***Error: Division by zero is not allowed.***\n");
            }
            break;
        default:
            printf("\n\t\t -->  ***Error: Invalid operator.***\n");
    }
}

