//29. Convert minutes into seconds and hours.

#include<stdio.h>
main() 

{
    int minutes;
    int seconds, hours, remaining_minutes;

    printf("\n\t Enter the number of minutes: ");
    scanf("%d", &minutes);
    printf("\n------------------------------------------------------------------------------------------\n");
    printf("--------------------------------------------------------------------------------------------\n");

    seconds=minutes*60;     // Convert minutes to seconds

    hours=minutes/60;     // Convert minutes to hours and remaining minutes
    remaining_minutes=minutes%60;

    printf("\n\t --> Convert minutes to seconds : ");
    printf(" | %d minutes | is | %d seconds | \n", minutes, seconds);
    printf("\n\t OR \n");
    printf("\n\t --> Convert minutes to hours and remaining minutes : ");
    printf(" | %d hours | & | %d minutes | \n", hours, remaining_minutes);
}

