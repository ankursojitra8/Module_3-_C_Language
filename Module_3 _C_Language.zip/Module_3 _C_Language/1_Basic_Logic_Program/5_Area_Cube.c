//5. Find Area of Cube formula : a = 6a2.

#include<stdio.h>
main()

{
    float side, area;

    printf("\n\t Enter the side length of the cube : ");
    scanf("%f", &side);

    area=6*side*side;     // Calculate the surface area of the cube

    printf("\n\t --> Surface area of the cube : %.2f\n", area);
}

