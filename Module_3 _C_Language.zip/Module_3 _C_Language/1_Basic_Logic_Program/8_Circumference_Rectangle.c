//8. Find circumference of Rectangle formula : C = 4 * a.

#include<stdio.h>
main()

{
    float width, length, perimeter;

    printf("Enter the width of the rectangle: ");
    scanf("%f", &width);
    printf("Enter the length of the rectangle: ");
    scanf("%f", &length);

    perimeter=2*(width+length);     // Calculate the perimeter of the rectangle

    printf("Perimeter of the rectangle: %.2f\n", perimeter);
}

