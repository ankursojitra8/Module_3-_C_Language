//7. Find area of Rectangle Formula : A=wl.

#include<stdio.h>
main()

{
    float width, length, area;

    printf("\n\t Enter the width of the rectangle: ");
    scanf("%f", &width);
    printf("\n\t Enter the length of the rectangle: ");
    scanf("%f", &length);
    printf("\n---------------------------------------------------------");

    area=width*length;     // Calculate the area of the rectangle

    printf("\n\t --> Area of the rectangle: %.2f\n", area);
}

