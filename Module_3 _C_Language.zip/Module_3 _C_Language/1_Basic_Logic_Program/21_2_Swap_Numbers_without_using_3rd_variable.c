//21_2. Accept 2 numbers from user and swap 2 numbers without using 3rd variable.

#include<stdio.h>
main()

{
    int num1, num2;

    // Input two numbers
    printf("\n\t Enter first number: ");
    scanf("%d", &num1);
    printf("\n\t Enter second number: ");
    scanf("%d", &num2);
    printf("\n-----------------------------------------------------------------------------\n");


    // Print original numbers
    printf("\n\t *** Original numbers: num1 = %d, num2 = %d *** \n", num1, num2);
    printf("\n-----------------------------------------------------------------------------\n");


    // Swap without using a third variable
    num1=num1+num2;
    num2=num1-num2;
    num1=num1-num2;

    // Print swapped numbers
    printf("\n\t --> Swapped numbers without using third variable: num1 = %d, num2 = %d \n\n", num1, num2);
}

