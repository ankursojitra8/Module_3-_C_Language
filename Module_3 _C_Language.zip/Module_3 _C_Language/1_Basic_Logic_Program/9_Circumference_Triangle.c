//9. Find circumference of Triangle formula : triangle = a + b + c 10.

#include<stdio.h>
main()

{
    float side1, side2, side3, perimeter;

    printf("\n\t Enter the length of side 1: ");
    scanf("%f", &side1);
    printf("\n\t Enter the length of side 2: ");
    scanf("%f", &side2);
    printf("\n\t Enter the length of side 3: ");
    scanf("%f", &side3);
    printf("\n---------------------------------------------------------");

    perimeter=side1+side2+side3;     // Calculate the perimeter of the triangle

    printf("\n\t --> Perimeter of the triangle: %.2f\n", perimeter);
}

