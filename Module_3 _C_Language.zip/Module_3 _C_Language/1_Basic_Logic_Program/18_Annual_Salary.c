//18. Calculate person's Annual salary.

#include<stdio.h>
main()

{
    float monthly_salary, annual_salary;

    printf("\n\t Enter the person's monthly salary: ");
    scanf("%f", &monthly_salary);

    annual_salary=monthly_salary*12;     // Calculate the annual salary

    printf("\n\t --> The annual salary is: %.2f\n", annual_salary);
}

