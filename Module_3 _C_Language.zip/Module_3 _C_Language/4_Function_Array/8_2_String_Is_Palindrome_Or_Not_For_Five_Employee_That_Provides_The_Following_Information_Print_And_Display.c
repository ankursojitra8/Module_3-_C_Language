/* 8_2. WAP of structure employee that provides the following :

(II).   Write a program of structure for five employee that provides the following information 
	empno, empname, address andage
*/

#include<stdio.h>

struct Employee 
{
    int empNo;
    char empName[100];
    char address[100];
    int age;
};

int inputEmployee(struct Employee *emp);
int printEmployee(struct Employee emp);
int inputAllEmployees(struct Employee emp[], int n);
int printAllEmployees(struct Employee emp[], int n);
int i;

main()
{
    struct Employee employees[5];
    inputAllEmployees(employees, 5);
    printAllEmployees(employees, 5);
}

inputEmployee(struct Employee*emp)
{
    int i;

    printf("\n\t Enter employee number : ");
    scanf("%d", &emp->empNo);
    getchar();  // For newline character left by previous input

    printf("\n\t Enter employee name (max 99 characters) : ");
    for(i=0;i<99&&(emp->empName[i]=getchar())!='\n';i++);
    emp->empName[i] = '\0'; 

    printf("\n\t Enter employee address (max 99 characters) : ");
    for(i=0;i<99&&(emp->address[i]=getchar())!='\n';i++);
    emp->address[i] = '\0'; 

    printf("\n\t Enter employee age : ");
    scanf("%d", &emp->age);
    getchar();  // Consume newline character left by age input
}

printEmployee(struct Employee emp) // Function to print employee details
{
    int i;
    printf("\n *** Employee Details ***");
    printf("\n\n\t Employee Number : %d", emp.empNo);
    printf("\n\n\t Employee Name : ");
    for(i=0; emp.empName[i]!='\0'; i++)
	{
        putchar(emp.empName[i]);
    }
    printf("\n\n\t Address : ");
    for(i = 0; emp.address[i] != '\0'; i++) 
	{
        putchar(emp.address[i]);
    }
    printf("\n\n\t Age : %d", emp.age);
}

inputAllEmployees(struct Employee emp[], int n) // Function to input details for all employees
{
    for(i=0;i<n;i++)
	{
        printf("\n\n\t Enter details for employee %d : ", i + 1);
        inputEmployee(&emp[i]);
    }
        printf("\n---------------------------------------------------");

}

printAllEmployees(struct Employee emp[], int n) // Function to print details of all employees
{    
	for(i=0;i<n;i++)
	{
        printf("\n---------------------------------------------------");
        printf("\n\n\t Details of employee %d : \n", i+1);
        printEmployee(emp[i]);
    }
}

