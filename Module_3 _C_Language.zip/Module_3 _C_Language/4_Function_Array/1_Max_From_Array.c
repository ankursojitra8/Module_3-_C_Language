// 1. Write a program to find out the max number from given array using function

#include<stdio.h>
#include<string.h>

int findMax(int arr[], int size);

main()
{
    int size, i;
    
    printf("\n\n\t Enter the number of elements in the array : \t ");
    scanf("%d", &size);
    
    int numbers[size];
    
    printf("\n\n\t Enter %d elements : ", size);
    for (i=0;i<size;i++)
        scanf("%d", &numbers[i]);
    
    int max=findMax(numbers, size);
    
    printf("\n\n\t --> The maximum number in the array is : %d \n", max);
}

findMax(int arr[], int size)
{
    int max=arr[0], i; // Asume the first element is the maximum

    for (i=1;i<size;i++)
	{
        if (arr[i]>max)
            max=arr[i]; // Update max if current element is greater
    }
}
