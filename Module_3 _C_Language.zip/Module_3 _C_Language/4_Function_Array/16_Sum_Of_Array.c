// 16. Accept 5 numbers from user and perform sum of array

#include<stdio.h>

main()
{
    int numbers[5], i, sum=0;

    printf("\n\t Enter 5 numbers : \n");
    for (i=0;i<5;i++)
	{
        printf("\n\t Number %d: ", i+1);
        scanf("%d", &numbers[i]);
    }

    for (i=0;i<5;i++)     // Calculate the sum of the array
	{
        sum+=numbers[i];
    }
    printf("\n------------------------------------------------\n");
    printf("\n\n\t --> Sum of the array elements : %d \n", sum);
}

