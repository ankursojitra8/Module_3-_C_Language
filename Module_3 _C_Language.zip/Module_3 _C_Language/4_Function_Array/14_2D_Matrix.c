// 14. Perform 2D matrix array

#include<stdio.h>

#define ROWS 3
#define COLS 3

main()
{
    int matrix[ROWS][COLS], i, j;

    printf("\n\tEnter elements of the matrix (%d x %d) :\n", ROWS, COLS);
    for (i=0;i<ROWS;i++)
	{
        for (j=0;j<COLS;j++)
		{
            printf("\n\t Element [ %d ][ %d ] : ", i+1, j+1);
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("\n-----------------------------\n");
    printf("\n --> The matrix is :\n");
    for (i=0;i<ROWS;i++)
	{
        for (j=0;j<COLS;j++)
		{
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

