// 12. WAP to accept 5 students name and store it in array
#include<stdio.h>

#define MAX_STUDENTS 5
#define MAX_NAME_LENGTH 100

main()
{
    char students[MAX_STUDENTS][MAX_NAME_LENGTH];
    int i;
    
    printf("\n\t Enter the names of 5 students : \n");
    for (i=0;i<MAX_STUDENTS;i++)
	{
        printf("\n\t Student %d : ", i+1);
        scanf("%s", students[i]);
    }
    
    printf("\n--------------------------------------\n");
    printf("\n\t *** Names of students *** \n");
    for (i=0; i<MAX_STUDENTS;i++)
	{
        printf("\n\n\t --> Student %d : %s\n", i+1, students[i]);
    }
}

