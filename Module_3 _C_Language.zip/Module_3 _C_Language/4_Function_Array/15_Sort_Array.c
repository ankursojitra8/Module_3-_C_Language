// 15. Store 5 numbers in array and sort it in ascending order

#include<stdio.h>
main()
{
    int numbers[5], i, j, temp;

    printf("\n\t Enter 5 numbers :");
    for (i=0;i<5;i++)
	{
        scanf("%d", &numbers[i]);
    }

    for (i=0;i<4;i++)     // Sort the array in ascending order using bubble sort
	{
        for (j=0;j<4-i;j++)
		{
            if (numbers[j]>numbers[j+1])
			{
                temp=numbers[j];
                numbers[j]=numbers[j+1];
                numbers[j+1]=temp;
            }
        }
    }
    printf("\n-------------------------------------------\n");
    printf("\n\n\t *** Sorted array in ascending order *** \n");
    for (i=0;i<5;i++)
	{
        printf("\n\t %d ", numbers[i]);
    }
    printf("\n");
}

