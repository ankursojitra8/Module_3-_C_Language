// 7. WAP Find out length of string without using inbuilt function

#include<stdio.h>

int stringLength(char str[]);

main() 
{
    char str[100];
    
    printf("\n\t Enter a string : ");
    fgets(str, sizeof(str), stdin);
    
    int length=stringLength(str);
    
    printf("\n------------------------------------------------");
    printf("\n\n\t --> The length of the string is : %d \n", length);
}

stringLength(char str[])  // Function to find the length of a string
{
    int length=0;
    
    while (str[length]!='\0')     // Traverse the string until null character is found
	{
        length++;
    }
    
    // If the string was read using fgets, subtract 1 from the length to exclude the newline character
    if (str[length-1]=='\n')
	{
        length--;
    }
    
    return length;
}

