// 9. WAP to show difference between Structure and Union.

#include<stdio.h>
struct Student
{
    int roll_no;
    char name[50];
    float marks;
};

union Data
{
    int int_val;
    float float_val;
    char char_val;
};

main()
{
    struct Student student = {1, "Alice", 88.5};    // Initialize and display structure
    printf("\n------------------------------------\n");
    printf("\n\t *** Structure Student *** \n\n\t Roll No : %d \n\t Name : %s\n\t Marks : %.2f \n\n", student.roll_no, student.name, student.marks);

    union Data data;     // Initialize and display union
    data.int_val=10;
    printf("\n------------------------------------\n");
    printf("\n\t *** Union Data *** \n\n\t Integer Value : %d ", data.int_val);

    data.float_val=3.14;
    printf("\n\t Float Value : %.2f ", data.float_val);

    data.char_val = 'A';
    printf("\n\t Char Value : %c\n", data.char_val);
}
}
