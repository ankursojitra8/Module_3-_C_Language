// 3. WAP to find reverse of string using recursion

#include<stdio.h>
#include<string.h>

void reverseString(char str[], int start, int end) 
{
    if (start>=end) 
	{
        return;
    } 
	else 
	{
        char temp=str[start];
        str[start]=str[end];
        str[end]=temp;
        
        reverseString(str, start+1, end-1);
    }
}

main()
{
    char str[100];
    
    printf(" \n\t Enter a string : ");
    scanf(" %*c", str);
    
    // Calculate length of string
    int len=strlen(str);
    
    // Reverse the string
    reverseString(str, 0, len-1);
    
    // Output the reversed string
    printf("\n\n\t --> Reversed string : %s \n", str);
}

