// 5. WAP to take two Array input from user and sort them in ascending or descending order as per user�s choice

#include<stdio.h>

int sortArray(int arr[], int size, int order);
int printArray(int arr[], int size);
int i, j;

main() 
{
    int size1, size2, temp, order;
    
    printf("\n\n\t Enter the number of elements in the first array : ");
    scanf("%d", &size1);
    printf("\n\n\t Enter the number of elements in the second array : ");
    scanf("%d", &size2);
    
    int arr1[size1], arr2[size2];
    
    printf("\n\n\t Enter %d elements for the first array : ", size1);
    for (i=0;i<size1;i++)
	{
        scanf("%d", &arr1[i]);
    }
    
    printf("\n\n\t Enter %d elements for the second array : ", size2);
    for (i=0;i<size2;i++)
	{
        scanf("%d", &arr2[i]);
    }
    
    printf("\n--------------------------------------------------------------------------");
    printf("\n\t -> Enter 1 for ascending order or 2 for descending order : "); // Ask the user for the sorting order
    scanf("%d", &order);
    
    sortArray(arr1, size1, order);    // Sort the arrays method
    sortArray(arr2, size2, order);
    
    printf("\n--------------------------------------------------------------------------");
    printf("\n\n\t --> First array after sorting : ");     // Print the sorted arrays
    printArray(arr1, size1);
    
    printf("\n--------------------------------------------------------------------------");
    printf("\n\n\t --> Second array after sorting : ");
    printArray(arr2, size2);
}

sortArray(int arr[], int size, int order) // Function to sort an array in ascending or descending order
{
	int temp;
    for (i=0;i<size-1;i++)
	{
        for (j=0;j<size-i-1;j++)
		{
            if ((order==1&&arr[j]>arr[j+1])||(order==2&&arr[j]<arr[j+1]))
			{
                temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
}

printArray(int arr[], int size) // Function to print an array
{
    for (i=0;i<size;i++)
	{
        printf("%d ", arr[i]);
    }
    printf("\n");
}
