/* 8_1. Write a program of structure employee that provides the following :

(I).   information -print and display empno, empname, address and age.
*/

#include<stdio.h>

struct Employee 
{
    int empNo;
    char empName[100];
    char address[100];
    int age;
};

void inputEmployee(struct Employee*emp);
void printEmployee(struct Employee emp);

main() 
{
    struct Employee emp;
    
    inputEmployee(&emp);
    
    printEmployee(emp);
}

void inputEmployee(struct Employee*emp)
{
    int i;

    printf("\n\t Enter employee number : ");
    scanf("%d", &emp->empNo);
    getchar();  // to consume the newline character left by previous scanf
    
    printf("\n\t Enter employee name : ");
    for(i=0;(emp->empName[i]=getchar())!='\n';i++);
    emp->empName[i] = '\0';  // Null terminate the string

    printf("\n\t Enter employee address : ");
    for(i=0;(emp->address[i]=getchar())!='\n';i++);
    emp->address[i]='\0';  // Null terminate the string

    printf("\n\t Enter employee age : ");
    scanf("%d", &emp->age);
}

void printEmployee(struct Employee emp) // Function to print employee details
{
    int i;
    printf("\n---------------------------------------------");
    printf("\n\n\t *** Employee Details ***");
    printf("\n\n\t Employee Number : %d", emp.empNo);
    printf("\n\n\t Employee Name : ");
    for(i=0;emp.empName[i]!='\0';i++)
	{
        putchar(emp.empName[i]);
    }
    printf("\n\n\t Address : ");
    for(i=0;emp.address[i]!='\0';i++)
	{
        putchar(emp.address[i]);
    }
    printf("\n\n\t Age : %d \n", emp.age);
}

