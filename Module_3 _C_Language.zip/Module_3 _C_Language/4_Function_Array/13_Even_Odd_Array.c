// 13. WAP to accept 5 numbers from user and check entered number is even or odd using of array

#include<stdio.h>

main()
{
    int numbers[5], i;

    printf("\n\t Enter 5 numbers : \n");
    for (i=0;i<5;i++)
	{
        printf("\n\t Number %d : ", i+1);
        scanf("%d", &numbers[i]);
    }

    printf("\n------------------------------------------------\n");
    printf("\n\t *** Even and Odd numbers *** \n");     // Check if each number is even or odd
    for (i=0;i<5;i++)
	{
        if (numbers[i] % 2 == 0)
            printf("\n\n\t --> Number %d -> ( %d ) is even.\n", i + 1, numbers[i]);
        else
            printf("\n\n\t --> Number %d -> ( %d ) is odd.\n", i + 1, numbers[i]);
    }
}

