// 10. WAP to perform Palindrome number using for loop and function

#include<stdio.h>

Palindrome(int num);

main()
{
    int num;
    
    printf("\n\t Enter a number : ");
    scanf("%d", &num);
    printf("\n------------------------------------\n");
    
    if (Palindrome(num))
        printf("\n\t --> | %d | is a palindrome. \n", num);
    else
        printf("\n\t --> | %d | is not a palindrome.\n", num);
}

Palindrome(int num) // Function to check if a number is a palindrome
{
    int originalNum=num, reversedNum=0, remainder;
    
    for (; num!=0; num/=10)
	{
        remainder=num%10;
        reversedNum=reversedNum*10+remainder;
    }
    
    if(originalNum==reversedNum)     // Check if the original number is equal to its reversed number
        return 1; 
    else
        return 0;
}
