// 5. Write a program in C to compare two strings without using string library functions.

#include<stdio.h>

compareStrings(char str1[], char str2[])
{
    int i=0;
    while (str1[i]&&str1[i]==str2[i])i++;
    return str1[i]-str2[i];
}

main()
{
    char str1[100], str2[100];
    int result;

    printf("\n\t Enter the first string : ");
    gets(str1); 

    printf("\n\t Enter the second string : ");
    gets(str2); 

    result=compareStrings(str1, str2);
    printf("\n----------------------------------------------");

    if (result == 0)
        printf("Strings are equal.\n");
    else if (result < 0)
        printf("\n\n\t --> First string is less than the second string.\n");
    else
        printf("\n\n\t --> First string is greater than the second string.\n");
}

