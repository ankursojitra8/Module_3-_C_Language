// 7. Write a program in C to copy one string to another string.

#include<stdio.h>

void copyString(char dest[], char src[])
{
    int i=0;
    while(src[i]!='\0')
	{
        dest[i]=src[i];
        i++;
    }
    dest[i]='\0';
}

main()
{
    char src[100], dest[100];

    printf("\n\t Enter a string : ");
    gets(src);

    copyString(dest, src);
    printf("\n----------------------------------------------");
    printf("\n\n\t --> Copied string : %s\n", dest);
}

