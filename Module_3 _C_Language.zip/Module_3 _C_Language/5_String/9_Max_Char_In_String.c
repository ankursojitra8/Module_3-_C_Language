// 9. Write a program in C to find the maximum number of characters in a string.

#include<stdio.h>

findLength(char str[])
{
    int length=0;
    while (str[length]!='\0')
        length++;
    return length;
}

main()
{
    char str[100];
    int i, length;

    printf("\n\t Enter a string : ");
    fgets(str, sizeof(str), stdin);

    for (i=0;str[i]!='\0';i++)     // Remove newline character if there is
	{
        if(str[i]=='\n')
		{
            str[i]='\0';
            break;
        }
    }

    length=findLength(str);
    printf("\n----------------------------------------------");
    printf("\n\n\t The length of the string is : %d \n", length);
}

