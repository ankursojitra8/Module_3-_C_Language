// 10. Write a program in C to extract a substring from a given string.

#include<stdio.h>

void extractSubstring(char *src, char *dest, int start, int length)
{
    int i;
    for (i=0;i<length&&src[start+i]!='\0';i++)
        dest[i]=src[start+i];
    dest[i]='\0';
}

main()
{
    char str[100], substr[100]; 
    int start, length;

    printf("\n\t Enter a string : ");
    fgets(str, sizeof(str), stdin);
    str[strcspn(str, "\n")]='\0'; // Remove newline

    printf("\n\t Enter start index and length : ");
    scanf("%d %d", &start, &length);
    printf("\n----------------------------------------------\n");

    if(start>=0&&length>0)
    {
        extractSubstring(str, substr, start, length);
        printf("\n\n\t Substring : %s\n", substr);
    }
    else
        printf("\n\n\t Invalid input.\n");
}

