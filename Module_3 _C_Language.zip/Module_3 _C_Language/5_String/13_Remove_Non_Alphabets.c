// 13. Write a program in C to remove characters from a string except alphabets.

#include<stdio.h>

isAlphabet(char c)
{
    return(c>='a'&&c<='z')||(c>='A'&&c<='Z');
}

main()
{
    char str[100], result[100];
    int i, j=0;

    printf("\n\t Enter a string : ");
    fgets(str, sizeof(str), stdin);

    str[strcspn(str, "\n")]='\0';

    for(i=0;str[i];i++)
	{
        if(isAlphabet(str[i]))
            result[j++]=str[i];
    }
    result[j]='\0';
    printf("\n----------------------------------------------\n");
    printf("\n\n\t --> String with only alphabets : %s\n", result);
}

