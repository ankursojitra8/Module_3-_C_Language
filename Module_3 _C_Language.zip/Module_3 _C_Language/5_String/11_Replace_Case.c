// 11. Write a program in C to read a sentence and replace lowercase characters with uppercase and vice versa.

#include<stdio.h>

main()
{
	int i;
    char str[100];

    printf("\n\t Enter a sentence : ");
    fgets(str, sizeof(str), stdin);

    for (i=0;str[i]!='\0';i++)
	{
        if(str[i]>='a'&&str[i]<='z')
            str[i]=str[i]-'a'+'A'; // Convert to uppercase
        else if(str[i]>='A'&&str[i]<='Z')
            str[i]=str[i]-'A'+'a'; // Convert to lowercase
    }
    printf("\n----------------------------------------------\n");
    printf("\n\n\t --> Modified sentence : %s\n", str);
}

