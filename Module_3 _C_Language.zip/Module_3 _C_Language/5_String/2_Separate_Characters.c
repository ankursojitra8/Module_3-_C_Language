// 2. Write a program in C to separate individual characters from a string.

#include<stdio.h>

main()
{
    char str[100];
    int i=0;

    printf("\n\t Enter a string : ");
    gets(str);
    printf("\n---------------------------------------------------------------\n");
    printf("\n\t *** separate individual characters from a string *** \n\n");

    while(str[i]!='\0')
	{
        printf("\t --> %c \n\t", str[i]);
        i++;
    }
}

