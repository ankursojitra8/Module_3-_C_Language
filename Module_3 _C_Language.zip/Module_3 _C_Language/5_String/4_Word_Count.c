// 4. Write a program in C to count the total number of words in a string.

#include<stdio.h>
#include<string.h>
main()
{
    char str[100];
    int i=0, count=0, inWord=0;

    printf("\n\t Enter a string : ");
    fgets(str, sizeof(str), stdin);

    str[strcspn(str, "\n")]='\0'; // Remove newline character if present

    while(str[i]!='\0')
	{
        if(str[i]==' '||str[i]=='\t'||str[i]=='\n')
            inWord = 0;
        else if(inWord==0)
		{
            count++;
            inWord=1;
        }
        i++;
    }
    printf("\n----------------------------------------------\n");
    printf("\n\n\t --> Total number of words : %d\n", count);
}

