// 14. Write a program in C to combine two strings manually

#include<stdio.h>
main()
{
    char str1[100], str2[100], result[200];
    int i=0, j=0;

    printf("\n\t Enter the first string : ");
    fgets(str1, sizeof(str1), stdin);

    printf("\n\t Enter the second string : ");
    fgets(str2, sizeof(str2), stdin);

    if(str1[strcspn(str1, " \n")]=='\n')str1[strcspn(str1, " \n")]='\0';
    if(str2[strcspn(str2, " \n")]=='\n')str2[strcspn(str2, " \n")]='\0';

    while(str1[i]!='\0')result[j++]=str1[i++];     // Copy str1 to result

    i=0;     // Copy str2 to result
    while(str2[i]!='\0')result[j++]=str2[i++];

    result[j]='\0'; // Null-terminate the result string
    printf("\n----------------------------------------------\n");
    printf("\n\n\t --> Combined string : %s\n", result);
}

