// 12. Write a program in C to find the number of times a given word 'is' appears in the given string.

#include<stdio.h>
#include<string.h>

main()
{
    char str[100], *ptr;
    int count = 0;

    printf("\n\t Enter a string : ");
    fgets(str, sizeof(str), stdin);

    str[strcspn(str, "\n")]='\0';

    ptr=str;
    while((ptr=strstr(ptr, "is"))!=NULL)
	{
        count++;
        ptr+=2; // Move past the last occurrence of "is"
    }
    printf("\n----------------------------------------------\n");
    printf("\n\n\t --> The word 'is' appears -> %d times.\n", count);
}

