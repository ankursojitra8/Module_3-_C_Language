// 8. Write a program in C to count the total number of vowels or consonants in a string.

#include<stdio.h>

void countVowelsConsonants(char str[], int *vowels, int *consonants)
{
    *vowels=*consonants=0;
    int i;

    for(i=0;str[i]!='\0';i++)
	{
        char ch = str[i];
        if(ch>='A'&&ch<='Z')
            ch+='a'-'A';
        if(ch>='a'&&ch<='z')
		{
            if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
                (*vowels)++;
            else
                (*consonants)++;
        }
    }
}
main()
{
    char str[100];
    int vowels, consonants;

    printf("\n\t Enter a string : ");
    fgets(str, sizeof(str), stdin);

    countVowelsConsonants(str, &vowels, &consonants);
    printf("\n----------------------------------------------");
    printf("\n\n\t --> Vowels : %d \n", vowels);
    printf("\n\n\t --> Consonants : %d \n", consonants);
}

