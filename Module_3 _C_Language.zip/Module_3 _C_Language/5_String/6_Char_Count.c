// 6. Write a program in C to count the total number of alphabets, digits and special characters in a string.

#include<stdio.h>

void countCharacters(char str[], int *alphabets, int *digits, int *special)
{
    *alphabets=*digits=*special=0;
    int i;

    for (i=0;str[i]!='\0';i++)
	{
        if((str[i]>='a'&&str[i]<='z')||(str[i]>='A'&&str[i]<='Z'))
            (*alphabets)++;
        else if(str[i]>='0'&&str[i]<='9')
            (*digits)++;
        else
            (*special)++;
    }
}

main()
{
    char str[100];
    int alphabets, digits, special;

    printf("\n\t Enter a string : ");
    gets(str);

    countCharacters(str, &alphabets, &digits, &special);

    printf("\n----------------------------------------------");
    printf("\n\n\t --> Alphabets : %d\n", alphabets);
    printf("\n\n\t --> Digits : %d\n", digits);
    printf("\n\n\t --> Special characters : %d\n", special);
}

