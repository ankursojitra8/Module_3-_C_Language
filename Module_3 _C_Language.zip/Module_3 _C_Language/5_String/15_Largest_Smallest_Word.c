// 15. Write a program in C to find the largest and smallest words in a string.

#include <stdio.h>
#include <string.h>

#define MAX 100
main()
{
    char str[MAX], word[MAX];
    char largest[MAX] = "", smallest[MAX] = "";
    int i=0, j=0;

    printf("\n\t Enter a string : ");
    fgets(str, sizeof(str), stdin);

    str[strcspn(str, "\n")]='\0';

    while(str[i])
	{
        j=0;
        while(str[i]&&str[i]!=' '&&str[i]!='\t'&&str[i]!='\n')
		{
            word[j++] = str[i++];
        }
        word[j]='\0';

        if(j>0)         // Compare word length
		{
            if(strlen(word)>strlen(largest))strcpy(largest, word);
            if(strlen(word)<strlen(smallest)||strlen(smallest)==0)strcpy(smallest, word);
        }

        while(str[i]==' '||str[i]=='\t'||str[i]=='\n')i++;         // Skip any whitespace
    }
    printf("\n----------------------------------------------\n");
    printf("\n\n\t --> Largest word : %s\n", largest);
    printf("\n\n\t --> Smallest word : %s\n", smallest);
}

