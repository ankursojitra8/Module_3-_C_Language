// 24. Accept month number and display month name.

#include<stdio.h>
main() 
{
    int i, monthNumber, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    char *months[] = {"January", "February", "March", "April", "May", "June",      // Array of month names
                      "July", "August", "September", "October", "November", "December"};

    printf("\n\t Enter the month number ( 1 - 12 ) : ");
    scanf("%d", &monthNumber);

    if (monthNumber<1||monthNumber>12)     // Check if the month number is valid
        printf("\n\n\t --> Invalid month number. Please enter a number between 1 and 12. \n");
    
	else
        printf("\n\n\t --> Month name : | %s | \n", months[monthNumber-1]);
    // Ask the user if they want to Check another Month of Year
    printf("\n *** Do you want to Check another Month of Year ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

