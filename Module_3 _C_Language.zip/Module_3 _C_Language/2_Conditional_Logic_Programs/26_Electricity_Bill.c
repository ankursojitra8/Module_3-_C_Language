/* 26. Write a C program to input electricity unit charges and calculate total electricity bill
according to the given condition : 

For first 50 units Rs. 0.50/unit
For next 100 units Rs. 0.75/unit
For next 100 units Rs. 1.20/unit
For unit above 250 Rs. 1.50/unit
An additional surcharge of 20% is added to the bill
*/

#include<stdio.h>
main()
{
    float units, totalBill, surcharge = 0.20, bill = 0.0;
    int i, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    // Input the units consumed from the user
    printf("\n\t Enter the electricity units consumed : ");
    scanf("%f", &units);

    // Calculate electricity bill based on unit slabs
    if(units<=50)
        bill=units*0.50;
        
    else if(units>50&&units<=150)
        bill=50*0.50+(units-50)*0.75;
        
    else if(units>150&&units<=250)
        bill=50*0.50+100*0.75+(units-150)*1.20;
        
    else if(units>250)
        bill=50*0.50+100*0.75+100*1.20+(units-250)*1.50;

    // Add surcharge
    totalBill=bill+(surcharge*bill);

    // Print the total electricity bill
    printf("\n\n\t --> Total electricity bill: | Rs. %.2f | \n", totalBill);
    // Ask the user if they want to Check for another units
    printf("\n *** Do you want to Check for another units ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

