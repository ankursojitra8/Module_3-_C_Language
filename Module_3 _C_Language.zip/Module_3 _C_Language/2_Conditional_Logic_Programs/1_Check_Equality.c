// 1. Write a C program to accept two integers and check whether they are equal or not?

#include<stdio.h>
main() 

{
	int i, num1, num2, continueChecking=1;
	
	for (; continueChecking=1;)
	{
    
	printf("\n\t  |< %d >| \n", i+1);
	i=i+1;
	
    printf("\n\t Enter the first integer: ");
    scanf("%d", &num1);

    printf("\n\t Enter the second integer: ");
    scanf("%d", &num2);
    printf("\n----------------------------------------------");
    printf("\n----------------------------------------------");


    if(num1==num2)
        printf("\n\t --> The integers are equal. \n");
	else
        printf("\n\t --> The integers are not equal. \n");
        
        // Ask the user if they want to Check another Integers
        printf("\n *** Do you want to check another character? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
        scanf("%d", &continueChecking);
        printf("\n--------------------------------------------------------------------------------------\n");
    }
}

