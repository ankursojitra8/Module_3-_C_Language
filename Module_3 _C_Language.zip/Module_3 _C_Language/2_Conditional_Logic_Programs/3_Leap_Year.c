// 3. WAP to check if the given year is a leap year or not.

#include<stdio.h>
main()

{
    int i, year, continueChecking=1;
    
    for (;continueChecking=1;)
    {
    	printf("\n |< %d >| \n", i+1);
		i=i+1;
	
  	  printf("\n\t Enter a year: ");
  	  scanf("%d", &year);

 	   if((year%4==0&&year%100!=0) || (year%400==0))   	// Check if the year is a leap year
        printf("\n\t --> %d is a leap year. \n", year);
		else
        printf("\n\t --> %d is not a leap year. \n", year);
    
    // Ask the user if they want to check another Year
        printf("\n *** Do you want to check another character? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
        scanf("%d", &continueChecking);
        printf("\n--------------------------------------------------------------------------------------\n");
	}
}

