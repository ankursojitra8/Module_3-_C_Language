/* 19. Write a program in C to calculate and print the electricity bill of a given customer.
The customer ID, name, and unit consumed by the user should be captured from the keyboard to
display the total amount to be paid to the customer. The charge are as follow :

1. Unit                             |            2. Charge/unit
3. upto 350                         |            4. @1.20
5. 350 and above but less than 600  |            6. @1.50
7. 600 and above but less than 800  |            8. @1.80
9. 800 and above                    |            10.@2.00
*/

#include<stdio.h>
main() 
{
    int i, customerID, continueChecking=1;
    char customerName[50];
    float unitsConsumed, totalAmount;

    for (;continueChecking==1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\n\t Enter Customer ID : ");
    scanf("%d", &customerID);

    printf("\n\n\t Enter Customer Name : ");
    scanf("%s", customerName); 

    printf("\n\n\t Enter Units Consumed : ");
    scanf("%f", &unitsConsumed);

    if (unitsConsumed<350)     // Calculate total amount based on units consumed
        totalAmount=unitsConsumed*1.20;
        
    else if (unitsConsumed<600)
        totalAmount=350*1.20 + (unitsConsumed-350)*1.50;
        
    else if (unitsConsumed<800)
        totalAmount=350*1.20 + 250*1.50 + (unitsConsumed-600)*1.80;
        
    else
        totalAmount=350*1.20 + 250*1.50 + 200*1.80 + (unitsConsumed-800)*2.00;

    printf("\n*** Electricity Bill ***\n");
    printf("\n\t )--> Customer ID : %d \n", customerID);
    printf("\n\t )--> Customer Name : %s \n", customerName);
    printf("\n\t )--> Units Consumed : %.2f \n", unitsConsumed);
    printf("\n\t )--> Total Amount to be Paid : | %.2f | \n", totalAmount);
    
	// Ask the user if they want to check another Customer.
    printf("\n *** Do you want to check another Customer ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
	scanf("%d", &continueChecking);
	printf("\n---------------------------------------------------------------------------------------------\n");
	}
}

