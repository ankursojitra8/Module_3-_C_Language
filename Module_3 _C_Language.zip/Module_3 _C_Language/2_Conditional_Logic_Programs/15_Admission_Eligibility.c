/* 15. Write a C program to determine eligibility for admission to a professional course based 
on the following criteria Eligibility Criteria : Marks in Maths >=65 and Marks in Phy >=55 and 
Marks in Chem>=50 and Total in all three subject >=190 or 
Total in Maths and Physics >=140 
-------------------------------------- Input the marks 
obtained in Physics :65 Input the marks obtained in Chemistry :51 Input the marks obtained
in Mathematics :72 Total marks of Maths, Physics and Chemistry : 188 
Total marks of Maths and Physics : 137 The candidate is not eligible.
*/

#include<stdio.h>
main() 
{
    int phy=65, chem=51, math=72, total, totalMathPhy;

    total=phy+chem+math;

    totalMathPhy=math+phy;

    printf("\n\n\t 1) --> Marks obtained in Physics : %d \n", phy);     
    printf("\n\n\t 2) --> Marks obtained in Chemistry : %d \n", chem);
    printf("\n\n\t 3) --> Marks obtained in Mathematics : %d \n", math);
    printf("\n----------------------------------------------------------------------------------");
    printf("\n----------------------------------------------------------------------------------");
    printf("\n\n\t TOTAL ) --->> Total marks of Maths, Physics and Chemistry : | %d | .\n", total);
    printf("\n\n\t 1 & 3)  --->> Total marks of Maths and Physics : | %d | .\n", totalMathPhy);

    if ((math>=65 && phy>=55 && chem>=50 && total>=190) || (totalMathPhy>=140))     // Check the eligibility criteria
        printf("\n\n\n\t --> The candidate is eligible.\n");
    else
        printf("\n\n\n\t --> The candidate is not eligible.\n");
        
}


