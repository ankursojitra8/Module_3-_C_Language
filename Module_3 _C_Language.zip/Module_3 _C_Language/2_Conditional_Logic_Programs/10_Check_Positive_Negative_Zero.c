// 10. WAP to check whether a number is negative, positive or zero.

#include<stdio.h>
main() 
{
    int i, number, continueChecking=1;

    for (;continueChecking==1;) 
	{
		printf("\n  |< %d >| \n", i+1);
		i=i+1;
        printf("\n\n\t Enter a number : ");
        scanf("%d", &number);

        if (number>0)         // Check if the number is Negative, Positive, or Zero
            printf("\n\t --> The number { %d } is positive.\n", number);
        else if (number<0)
            printf("\n\t --> The number { %d } is negative.\n", number);
        else
            printf("\n\t --> The number is zero.\n");

        // Ask the user if they want to check another number
        printf("\n *** Do you want to check another number ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
 		scanf("%d", &continueChecking);
 		printf("\n---------------------------------------------------------------------------------------------\n");
    }
}

