/* 21. Write a program in C to read any Month Number in integer and display the
number of days for this month.
*/

#include<stdio.h>
main() 
{
    int i, month, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\t Enter the month number ( 1 - 12 ) : ");
    scanf("%d", &month);

    if (month<1||month>12)     // Check if the month number is valid
        printf("\n\t Invalid month number. Please enter a number between 1 & 12. \n");
    else
        switch (month)         // Determine the number of days based on the month number
		{
            case 1:  // January
            case 3:  // March
            case 5:  // May
            case 7:  // July
            case 8:  // August
            case 10: // October
            case 12: // December
                printf("\n\t Number of days : 31 \n");
                break;
            case 4:  // April
            case 6:  // June
            case 9:  // September
            case 11: // November
                printf("\n\t Number of days : 30 \n");
                break;
            case 2:  // February
                printf("\n\t Number of days : 28 or 29 (depending on whether it's a leap year) \n");
                break;
        }
    // Ask the user if they want to check another Month
    printf("\n *** Do you want to check another Month ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

