// 18. Write a C program to calculate profit and loss on a transaction.

#include<stdio.h>
main() 
{
    float costPrice, sellingPrice, profit, loss;
    int i, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\t Enter the Cost Price : ");
    scanf("%f", &costPrice);

    printf("\n\t Enter the Selling Price : ");
    scanf("%f", &sellingPrice);

    if (sellingPrice>costPrice)     // Calculate profit or loss
    {
        profit=sellingPrice-costPrice;
        printf("\n\t --> Profit : | %.2f | \n", profit);   
	}
    else if (costPrice>sellingPrice)
    {
        loss=costPrice-sellingPrice;
        printf("\n\t --> Loss : | %.2f | \n", loss);
    
	}
    else
        printf("\n\t --> No Profit, No Loss.\n");    	
	// Ask the user if they want to perform another calculation
    printf("\n *** Do you want to check another calculation ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

