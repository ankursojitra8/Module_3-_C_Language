/* 20. If bill exceeds Rs. 800 then a surcharge of 18% will be charged andthe minimum bill
should be of Rs. 256/-
*/

#include<stdio.h>
main() 
{
    float billAmount, totalAmount, surchargeRate = 0.18;  // 18% surcharge rate
    float minimumBill = 256.0;   // Minimum bill amount

    printf("\n\t Enter the bill amount : ");
    scanf("%f", &billAmount);

    if (billAmount>800)     // Calculate total amount including surcharge if applicable
        totalAmount=billAmount+(billAmount*surchargeRate);
    else
        totalAmount=billAmount;

    if (totalAmount<minimumBill)     // Ensure the total amount is not less than the minimum bill
        totalAmount=minimumBill;

    printf("\n\n\t --> Total Amount to be Paid : | Rs. %.2f | \n", totalAmount);
}

