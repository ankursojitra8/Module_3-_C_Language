/* 27. WAP to show
i.  Monday to Sunday using switch case
*/

#include<stdio.h>
main()
{
    int i, day, continueCalculation=1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\t Enter a number ( 1 - 7 ) to get the corresponding day of the week : ");
    scanf("%d", &day);

    switch(day)      // Determine the day of the week using a switch statement
	{
        case 1:
            printf("\n\t --> Monday \n");
            break;
        case 2:
            printf("\n\t --> Tuesday \n");
            break;
        case 3:
            printf("\n\t --> Wednesday \n");
            break;
        case 4:
            printf("\n\t --> Thursday \n");
            break;
        case 5:
            printf("\n\t --> Friday \n");
            break;
        case 6:
            printf("\n\t --> Saturday \n");
            break;
        case 7:
            printf("\n\t --> Sunday \n");
            break;
        default:
            printf("/n/t *** Invalid input! Please enter a number between 1 & 7.*** \n");
    }
    // Ask the user if they want to Check for another units
    printf("\n *** Do you want to Check for another units ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

