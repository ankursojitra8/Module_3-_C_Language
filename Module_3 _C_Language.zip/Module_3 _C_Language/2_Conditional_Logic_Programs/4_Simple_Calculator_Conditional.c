/* 4. WAP to make simple calculator (operation include Addition, Subtraction, Multiplication, Division,
modulo) using conditional statement.
*/
#include<stdio.h>
main()

{
    int i, num1, num2, result, continueCalculation = 1;
    char operator;


    for (;continueCalculation==1;) 
	{
		printf("\n  |< %d >| \n", i+1);
		i=i+1;
        printf("\n\t Enter the first integer :           ");
        scanf("%d", &num1);

        printf("\n\t Enter an operator (+, -, *, /, %%) : ");
        scanf(" %c", &operator);  
        
        printf("\n\t Enter the second integer :          ");
        scanf("%d", &num2);
        printf("\n---------------------------------------------------");
        printf("\n---------------------------------------------------\n");

        switch (operator) 
		{
            case '+':
                result = num1 + num2;
                printf("\n\t\t Result : %d %c %d = %d \n", num1, operator, num2, result);
                break;
            case '-':
                result = num1 - num2;
                printf("\n\t\t Result : %d %c %d = %d \n", num1, operator, num2, result);
                break;
            case '*':
                result = num1 * num2;
                printf("\n\t\t Result : %d %c %d = %d \n", num1, operator, num2, result);
                break;
            case '/':
                if (num2 != 0) 
					{
                    result = num1 / num2;
                    printf("\n\t\t Result : %d %c %d = %d \n", num1, operator, num2, result);
                	} 
				else 
                    printf("\n\t\t Error : Division by zero is not allowed. \n");
                break;
            case '%':
                if (num2 != 0) 
					{
                    result = num1 % num2;
                    printf("\n\t\t Result : %d %c %d = %d \n", num1, operator, num2, result);
                	} 
				else 
                    printf("\n\t\t Error : Division by zero is not allowed. \n");
                break;
            default:
                printf("\n\t\t Error: Invalid operator. \n");
                break;
        }

        // Ask the user if they want to perform another calculation
        printf("\n *** Do you want to check another character? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
        scanf("%d", &continueCalculation);
        printf("\n------------------------------------------------------------------------------------------------");
    }
}

