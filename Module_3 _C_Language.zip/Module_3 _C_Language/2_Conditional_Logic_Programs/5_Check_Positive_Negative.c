// 5. Check Number Is Positive or Negative.

#include<stdio.h>
main()

{
	int l, i, continuechecknum=1;
	
	for(;continuechecknum=1;)
	{
	
		printf("\n  |< %d >| \n", l+1);
		l=l+1;
		
		printf("\n\n\t Enter a number for Check Number Is Positive or Negative : ");
		scanf("%d", &i);
		
		if (i>0)
			printf("\n\t --> The number : { %d } is Positive \n",i);
		else if (i<0)
			printf("\n\t --> The number : { %d } is Negative \n",i);
		else
			printf("\n\t --> The number : { %d } is Neutral / Zero \n",i);
		// Ask the user if they want to Check another number
        printf("\n *** Do you want to check another character? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
 		scanf("%d", &continuechecknum);
 		printf("\n---------------------------------------------------------------------------------------------\n");
    }
}
