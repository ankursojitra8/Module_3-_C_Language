/* 27_2. WAP to show
ii. Vowel or Consonant using switch case
*/
#include <stdio.h>
main()
{
    char ch;
    int i, day, continueCalculation=1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\t Enter a character : ");
    scanf(" %c", &ch);

    ch=tolower(ch);

    switch(ch)
	{
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u':
        case 'A':
        case 'E':
        case 'I':
        case 'O':
        case 'U':
            printf("\n\n\t --> | %c | is a vowel. \n", ch);
            break;
        default:
            if ((ch>='a'&&ch<='z'))             // Check if the character is an alphabet letter
                printf("\n\n\t --> | %c | is a consonant. \n", ch);
            else
                printf("\n\n\t --> | %c | is not a valid alphabet letter. \n", ch);
    }
    // Ask the user if they want to Check for another Alphabet
    printf("\n *** Do you want to Check for another Alphabet ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

