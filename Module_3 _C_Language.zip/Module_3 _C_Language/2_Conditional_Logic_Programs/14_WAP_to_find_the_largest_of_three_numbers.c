// 14. WAP to find the largest of three numbers.

#include<stdio.h>
main() 
{
    int i, num1, num2, num3, max, continueChecking=1;
    
    for(;continueChecking=1;)
    {
	    
    printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\n\t Enter the first number : ");
    scanf("%d", &num1);

    printf("\n\n\t Enter the second number : ");
    scanf("%d", &num2);

    printf("\n\n\t Enter the third number : ");
    scanf("%d", &num3);

    if (num1>=num2 && num1>=num3)     // Find the largest number
        max = num1;
    else if (num2>=num1 && num2>=num3)
        max = num2;
    else
        max = num3;

    printf("\n\t --> The largest number among %d, %d, and %d is | %d | .\n", num1, num2, num3, max);
    
    // Ask the user if they want to check another set of numbers
    printf("\n *** Do you want to check another set of number ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
	scanf("%d", &continueChecking);
	printf("\n---------------------------------------------------------------------------------------------\n");
	}
}

