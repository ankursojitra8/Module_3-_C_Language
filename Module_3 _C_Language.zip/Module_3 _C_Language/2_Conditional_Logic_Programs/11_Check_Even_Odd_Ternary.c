// 11. WAP to find number is even or odd using ternary operator.

#include<stdio.h>
main() 
{
    int i, number, continueChecking = 1;

    for (;continueChecking==1;) 
	{
		printf("\n  |< %d >| \n", i+1);
		i=i+1;
        printf("\n\t Enter a number: ");
        scanf("%d", &number);

        // Determine if the number is even or odd using the ternary operator
        (number%2==0) ? printf("\n\t --> The number %d is even.\n", number) : printf("\n\t --> The number %d is odd.\n", number);

        // Ask the user if they want to check another number
        printf("\n *** Do you want to check another number ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
 		scanf("%d", &continueChecking);
 		printf("\n---------------------------------------------------------------------------------------------\n");
    }
}
