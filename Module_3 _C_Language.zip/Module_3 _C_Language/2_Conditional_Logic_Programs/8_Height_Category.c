/// 8. WAP to accept the height of a person in centimeters and categorize the person according to their height.

#include<stdio.h>
main() 
{
    int i, height, continueChecking=1;

    for (;continueChecking==1;) 
	{
		printf("\n  |< %d >| \n", i+1);
		i=i+1;
        printf("\n\n\t Enter the height in centimeters: ");
        scanf("%d", &height);

        if (height<145)         // Categorize the person based on their height
            printf("\n\t --> The person is categorized as Short.\n");
        else if (height<=175)
            printf("\n\t --> The person is categorized as Average.\n");
        else
            printf("\n\t --> The person is categorized as Tall.\n");

        // Ask the user if they want to check another height
        printf("\n *** Do you want to check another height ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
 		scanf("%d", &continueChecking);
 		printf("\n---------------------------------------------------------------------------------------------\n");
    }
}

