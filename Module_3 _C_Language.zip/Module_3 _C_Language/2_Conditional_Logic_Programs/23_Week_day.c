// 23. WAP to input the week number and print week day.

#include<stdio.h>
main() 
{
    int i, weekNumber, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\t Enter the week number ( 1 - 7 ) : ");
    scanf("%d", &weekNumber);

    switch (weekNumber)      // Determine the weekday based on the week number
	{
        case 1:
            printf("\n\n\t --> Day of the week : Monday \n");
            break;
        case 2:
            printf("\n\n\t --> Day of the week : Tuesday \n");
            break;
        case 3:
            printf("\n\n\t --> Day of the week : Wednesday \n");
            break;
        case 4:
            printf("\n\n\t --> Day of the week : Thursday \n");
            break;
        case 5:
            printf("\n\n\t --> Day of the week : Friday \n");
            break;
        case 6:
            printf("\n\n\t --> Day of the week : Saturday \n");
            break;
        case 7:
            printf("\n\n\t --> Day of the week : Sunday \n");
            break;
        default:
            printf("\n\n\t --> Invalid week number. Please enter a number between 1 to 7.\n");
    }
    // Ask the user if they want to perform another Day of the week
    printf("\n *** Do you want to perform another Day of the week ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

