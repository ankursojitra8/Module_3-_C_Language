// 17. Write a C program to check whether a triangle can be formed with the given values for the angles.

#include<stdio.h>
main() 

{
    int i,angle1, angle2, angle3, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;
    
    printf("\n\t Enter the first angle : ");
    scanf("%d", &angle1);
    
    printf("\n\t Enter the second angle : ");
    scanf("%d", &angle2);
    
    printf("\n\t Enter the third angle : ");
    scanf("%d", &angle3);

    int sumAngles=angle1+angle2+angle3;     // Calculate the sum of the angles

    if (sumAngles==180 && angle1>0 && angle2>0 && angle3>0)     // Check if a triangle can be formed
        printf("\n\t --> The angles %d, %d, and %d can form a triangle. \n", angle1, angle2, angle3);
    else
        printf("\n\t --> The angles %d, %d, and %d cannot form a triangle. \n", angle1, angle2, angle3);
    // Ask the user if they want to perform another calculation
    printf("\n *** Do you want to perform another calculation ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}
