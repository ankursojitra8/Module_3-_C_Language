// 7. Accept marks from user and check pass or fail

#include<stdio.h>
main() 

{
    int i, marks, continueChecking=1;

    for (;continueChecking==1;) 
	{
		printf("\n  |< %d >| \n", i+1);
		i=i+1;
        printf("\n\n\t Enter the marks: ");
        scanf("%d", &marks);

        if (marks>=33)         // Check if the marks are passing or failing
            printf("\n\n\t --> The student has passed.\n");
        else
            printf("\n\n\t --> The student has failed.\n");

        // Ask the user if they want to check another set of marks
        printf("\n *** Do you want to check another Marks? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
 		scanf("%d", &continueChecking);
 		printf("\n---------------------------------------------------------------------------------------------\n");
    }
}

