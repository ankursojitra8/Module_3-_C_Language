// 6. Find the Character Is Vowel or Not.

#include<stdio.h>
main()
{
    char ch;
    int i, continueChecking = 1;

    for (; continueChecking == 1;) 
	{
		printf("\n  |< %d >| \n", i+1);
		i=i+1;
        printf("\n\n\t Enter a character: ");
        scanf(" %c", &ch);

        if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||    // Check if the character is a vowel
            ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') 
			printf("\n\n\t --->> The character : '%c' is a vowel.\n", ch);
        else
            printf("\n\n\t --->> The character : '%c' is not a vowel.\n", ch);


        // Ask the user if they want to check another character
        printf("\n *** Do you want to check another character? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
 		scanf("%d", &continueChecking);
 		printf("\n---------------------------------------------------------------------------------------------\n");
    }
}

