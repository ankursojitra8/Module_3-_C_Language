// 25. Accept the input month number and print number of days in that month.

#include<stdio.h>
main() 
{
    int i,monthNumber, days, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\t Enter the month number ( 1 - 12 ) : ");
    scanf("%d", &monthNumber);

    switch (monthNumber)      // Determine the number of days based on the month number
	{
        case 1:  // January
        case 3:  // March
        case 5:  // May
        case 7:  // July
        case 8:  // August
        case 10: // October
        case 12: // December
            days = 31;
            break;
        case 4:  // April
        case 6:  // June
        case 9:  // September
        case 11: // November
            days = 30;
            break;
        case 2:  // February
            days = 28; // Assuming non-leap year by default
            break;
        default:
            printf("\n\t *** --> Invalid month number. Please enter a number between 1 and 12.*** \n");
            return 1;
    }

    printf("\n\n\t --> | %d | is a specified month have number of days is : | %d | \n", monthNumber, days);
    
    // Ask the user if they want to Check the number of days in the specified month
    printf("\n *** Do you want to Check the number of days in the specified month ? Enter 1 for Yes, 0 for No: *** \n\n  --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

