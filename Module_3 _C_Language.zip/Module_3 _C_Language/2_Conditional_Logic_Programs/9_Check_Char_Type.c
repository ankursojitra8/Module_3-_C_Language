// 9. C Program to Check Uppercase or Lowercase or Digit or Special Character.

#include<stdio.h>
main() 
{
    char ch;
    int i, continueChecking=1;

    for (;continueChecking==1;) 
	{
		printf("\n  |< %d >| \n", i+1);
		i=i+1;
        printf("\n\n\t Enter a character: ");
        scanf(" %c", &ch);

        if (ch>='A'&&ch<='Z')        // Check if the character is uppercase, lowercase, digit, or special character
            printf("\n\t --> The character : '%c' is an uppercase letter.\n", ch);
            
        else if (ch>='a'&&ch<='z')
            printf("\n\t --> The character : '%c' is a lowercase letter.\n", ch);
            
        else if (ch>='0'&&ch<='9')
            printf("\n\t --> The character : '%c' is a digit.\n", ch);
            
        else
            printf("\n\t --> The character : '%c' is a special character.\n", ch);
        
        // Ask the user if they want to check another character
        printf("\n *** Do you want to check another character ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
 		scanf("%d", &continueChecking);
 		printf("\n---------------------------------------------------------------------------------------------\n");
    }
}

