// 21. Accept 3 numbers from user using while loop and check each numbers palindrome.

#include <stdio.h>

isPalindrome(int num) 
{
    int reversed=0, original=num, remainder;
    
    while (num!=0)     // Reversing the number
	{
        remainder=num%10;
        reversed=reversed*10+remainder;
        num/=10;
    }
    
    return(original==reversed);     // Check if the original number and reversed number are the same
}

main()
{
    int count=0, num;
    
    while (count<3)     // Input 3 numbers using while loop
	{
        printf("\n\n\t Enter number ( %d ) : ", count+1);
        scanf("%d", &num);
        
        if (isPalindrome(num))         // Check if the number is a palindrome
            printf("\n\n\t --> Number | %d | is a palindrome. \n", num);
        else
            printf("\n\n\t --> Number | %d | is not a palindrome.\n", num);
            
        count++;
    }
}


