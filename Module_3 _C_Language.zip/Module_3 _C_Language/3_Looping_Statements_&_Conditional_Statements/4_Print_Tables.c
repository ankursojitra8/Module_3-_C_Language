// 4. WAP to print table up to given numbers.

#include<stdio.h>
main()

{
    int p, i, number, limit, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", p+1);
	p=p+1;

    printf("\n\t Enter the number for which you want the multiplication table : ");
    scanf("%d", &number);     // Input the number for which table is required

    printf("\n\t Enter the limit up to which you want to print the table : ");
    scanf("%d", &limit);     // Input the limit up to which table is to be printed

    printf("\n\t Multiplication table for | %d | up to | %d | : \n", number, limit);     // Print the multiplication table
    for (i = 1; i <= limit; ++i) 
        printf("\n\n\t --> %d x %d = | %d | \n", number, i, number*i);
        
    // Ask the user if they want to Perform an another number
    printf("\n *** Do you want to Perform an another number ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}




