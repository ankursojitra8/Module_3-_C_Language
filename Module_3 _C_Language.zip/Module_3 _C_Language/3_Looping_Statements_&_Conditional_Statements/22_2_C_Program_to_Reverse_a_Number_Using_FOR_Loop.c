/* 22_2. C Program to Reverse a Number Using FOR Loop
--> Series Program:
B. (1*1) + (2*2) + (3*3) + (4*4) + (5*5) + ... + (n*n)
*/

#include<stdio.h>
main()
{
    int n, i, sum=0;

    printf("\n\t Enter a positive integer : ");
    scanf("%d", &n);

    for (i=1;i<=n;++i)     // Calculate the sum of squares
        sum+=i*i;

    printf("\n\t --> Sum of squares from 1^2 to %d^2 is : | %d | \n", n, sum);
}

