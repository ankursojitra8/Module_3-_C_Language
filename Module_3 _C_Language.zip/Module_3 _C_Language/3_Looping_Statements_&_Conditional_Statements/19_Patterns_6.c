/* 19_6. Patterns :
                         
Pattern 6 : A
            A  B
            A  B  C
            A  B  C  D
            A  B  C  D  E
*/ 

#include<stdio.h>
main() 
{
    int rows, i, j;
    char currentChar;

    printf("\n\t --> Enter the number of rows {1 - 26} : ");
    scanf("%d", &rows);

    for (i=0;i<rows;++i)     // Loop to iteract through each row
	{
        char currentChar = 'A';

        for (j=0;j<=i;++j)         // Print letters in each row
            printf("%c ", currentChar++);

        printf("\n");
    }
}

