// 5. WAP to print factorial of given number.

#include <stdio.h>
main()
{
    int i, number, factorial = 1, p, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", p+1);
	p=p+1;

    printf("\n\t Enter a number to calculate its factorial : ");
    scanf("%d", &number);

    for (i=1;i<=number;++i)     // Calculate factorial using a for loop
        factorial *= i;

    printf("\n\n\t --> Factorial of | %d | is : | %d | \n", number, factorial);     // Print the factorial
    
    // Ask the user if they want to Perform an another number
    printf("\n *** Do you want to Perform an another number ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

