/* 22_3. C Program to Reverse a Number Using FOR Loop
--> Series Program:
C. (1)+ (1+2) + (1+2+3) + (1+2+3+4) + ... + (1+2+3+4+...+n)
*/

#include<stdio.h>
main()
{
    int n, i, j, sum=0;

    printf("\n\t Enter a positive integer : ");
    scanf("%d", &n);

    for (i=1;i<=n;++i)     // Calculate the sum of the series
	{
        int innerSum=0;
        
        for (j=1;j<=i;++j)
            innerSum+=j;
            
        sum+=innerSum;
        printf("\n\n( %d )   ", innerSum);
    }
    printf("\n\n\n\t --> Sum of the series is: %d\n", sum);
}

