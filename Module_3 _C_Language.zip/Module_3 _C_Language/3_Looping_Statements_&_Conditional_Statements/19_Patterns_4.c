/* 19_4. Patterns :
Pattern 4 : *
            * *
            * * *
            * * * *
            * * * * *  
            * * * * * *
	        * * * * *                           
            * * * * 
            * * *
            * *
            *
*/ 

#include<stdio.h>
main()
{
    int rows, i, j;

    // Input the number of rows
    printf("\n\t --> Enter the number of rows (maximum 20) : ");
    scanf("%d", &rows);

    if (rows<1||rows>20)
	{
        printf("\n\t Invalid input. Please enter a number between 1 and 20. \n");
        return 1;
    }

    for (i=0;i<rows;++i)      // Upper part of the diamond
	{
        for (j=0;j<=i;++j)         // Print asterisks in increasing order
            printf("* ");
        printf("\n"); // Move to the next line after each row
    }

    for (i=rows-1;i>0;--i)     // Lower part of the diamond
	{
        for (j=0;j<i;++j)
		{
            printf("* ");
        }
        printf("\n");
    }
}

