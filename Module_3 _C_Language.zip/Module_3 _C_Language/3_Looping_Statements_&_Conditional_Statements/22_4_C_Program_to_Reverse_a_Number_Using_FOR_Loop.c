/* 22_4. C Program to Reverse a Number Using FOR Loop
--> Series Program:
D. 1/2 - 2/3 + 3/4 - 4/5 + 5/6 .......... n
*/

#include<stdio.h>
main()
{
    int n, i, sign=1;
    float sum = 0.0;

    printf("\n\t Enter a positive integer : ");
    scanf("%d", &n);

    for (i=1;i<=n;++i)      // Calculate the sum of the series
	{
        sum+=sign*((float)i/(i+1));
        sign=-sign;
    }

    printf("\n\n\t --> Sum of the series is : | %.2f | \n", sum);
}

