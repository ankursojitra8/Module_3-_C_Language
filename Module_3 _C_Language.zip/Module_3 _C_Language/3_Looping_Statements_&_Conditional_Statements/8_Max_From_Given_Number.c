// 8. Write a program to find out the max from given number (E.g., No: -1562 Max number is 6).

#include<stdio.h>
main() 
{
    int number= -1562, max_digit = 0, temp, digit=temp%10;

    printf("\n\tOriginal number : %d \n", number);

    for (temp=number;temp!=0;temp/=10)     // Use a for loop to find the maximum digit
        digit=temp%10;
        if (digit>max_digit)
            max_digit=digit;

    printf("\n\n\t Max digit: | %d | \n", max_digit);
}

