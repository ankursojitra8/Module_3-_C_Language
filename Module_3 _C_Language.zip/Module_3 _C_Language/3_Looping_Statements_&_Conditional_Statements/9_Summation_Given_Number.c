// 9. Write a program make a summation of given number (E.g., 1523 Ans: -11).

#include<stdio.h>
main()
{
    int number=1523, sum=0, temp, digit;

    printf("\n\t Original number : %d \n", number);

    for (temp=number;temp!=0;temp/=10)     // Use a for loop to find the sum of the digits
	{
        digit=temp%10;
        sum+=digit;
    }
        
    if (number<0)     // Adjust the sum for the negative original number
    sum=number+-sum;
    printf("\n\n\t --> Sum of the digits: %d \n", sum);
}
