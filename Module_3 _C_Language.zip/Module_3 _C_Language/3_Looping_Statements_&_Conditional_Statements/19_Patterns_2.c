/* 19_2. Patterns :
Pattern 2 : A
            B  C
            D  E  F
            G  H  I  J    
            K  L  M  N  O
*/ 

#include<stdio.h>
main()
{
    int rows, i, j;
    char currentChar = 'A';

    printf("\n\t --> Enter the number of rows (maximum 5) : ");
    scanf("%d", &rows);

    if (rows<1||rows>5) 
	{
        printf("\n\t Invalid input. Please enter a number between 1 and 5. \n");
        return 1;
    }

    for (i=0;i<rows;++i)     // Loop to iterate through each row
	{
        for (j=0;j<=i;++j)
            printf("  %c  ", currentChar++);

        printf("\n");
    }
}

