/* 3. WAP to take 10 no. Input from user find out below value.

a. How many Even numbers are there
b. How many odd numbers are there
c. Sum of even numbers
d. Sum of odd numbers
*/

#include<stdio.h>
main() 
{
    int p, numbers[10],evenCount = 0, oddCount=0, sumEven=0, sumOdd=0,  i, continueCalculation=1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", p+1);
	p=p+1;

    printf("\n\t Enter 10 numbers : \n");

    for (i=0;i<10;++i)     // Reading input from user
	{
        printf("\n\t Enter number ( %d ) : ", i + 1);
        scanf("%d", &numbers[i]);

        if (numbers[i]%2==0)         // Check if number is even or odd
		{
            evenCount++;
            sumEven+=numbers[i];
        }
		else
		{
            oddCount++;
            sumOdd+=numbers[i];
        }
    }

    printf("\n\n\t --> Number of even numbers  : | %d | \n", evenCount);     // Display results
    printf("\n\n\t --> Number of odd numbers : | %d | \n", oddCount);
    printf("\n\n\t --> Sum of even numbers : | %d | \n", sumEven);
    printf("\n\n\t --> Sum of odd numbers : | %d | \n", sumOdd);
    // Ask the user if they want to Perform an another number
    printf("\n *** Do you want to Perform an another number ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

