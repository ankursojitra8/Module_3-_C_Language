// 12_1. Program of Armstrong Number in C Using For Loop

#include<stdio.h>
main() 
{
    int i, number, originalNumber, remainder, result=0, n=0, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\t Enter an integer : ");
    scanf("%d", &number);

    originalNumber=number;

    for (;originalNumber!=0;originalNumber/=10,++n);

    originalNumber=number;

    for (;originalNumber!=0;originalNumber/=10)     // Calculate sum of nth power of digits
	{
        remainder=originalNumber%10;
        result+=pow(remainder,n);
    }

    if (result==number)     // Check if number is Armstrong
        printf("\n\n\t --> | %d  | is an Armstrong number. \n", number);
    else
        printf("\n\n\t --> | %d  | is not an Armstrong number. \n", number);
        
    // Ask the user if they want to Check if number is Armstrong
    printf("\n *** Do you want to Check if number is Armstrong ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

