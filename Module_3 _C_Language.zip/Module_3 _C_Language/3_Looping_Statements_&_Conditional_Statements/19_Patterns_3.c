/* 19_3. Patterns :
Pattern 3 :      *
               * * *
              * * * *
             * * * * *
            * * * * * *
*/ 

#include<stdio.h>
main()
{
    int rows, i, j, space;

    printf("\n\t --> Enter the number of rows (maximum 20) : ");
    scanf("%d", &rows);

    if (rows<1||rows>20)
	{
        printf("\n\t Invalid input. Please enter a number between 1 and 5. \n");
        return 1;
    }

    for (i=0;i<rows;++i)
	{
        for (space=1; space<rows-i;++space)         // Print spaces to center the pyramid
            printf(" ");
            
        for (j=0;j<=i;++j)         // Print asterisks in increasing order
            printf("* ");

        printf("\n");
    }
}
