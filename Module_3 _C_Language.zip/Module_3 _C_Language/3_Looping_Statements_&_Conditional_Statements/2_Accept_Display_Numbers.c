// 2. WAP to accept 5 numbers from user and display all numbers.

#include<stdio.h>
main()
{
    int numbers[5],  i, n, continueCalculation=1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", n);
	n=n+1;

    printf("\n\t ***** Enter 5 numbers : *****\n");

    for (i=0;i<5;++i)
	{
        printf("\n\t Enter number (%d) : ", i );
        scanf("%d", &numbers[i]);
    }

    printf("\n\t Numbers entered : ");     // Displaying all numbers entered
    printf("\n-------------------------------------------");

    for (i=0;i<5;++i) 
	{
        printf("\n\t %d --> | %d | ",i, numbers[i]);
    }
    printf("\n");
	// Ask the user if they want to Check for another units
    printf("\n *** Do you want to Check for another units ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

