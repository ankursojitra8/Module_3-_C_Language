/* 19_1. Patterns :
Pattern 1 : 1            
			1  0
			1  0  1
			1  0  1  0
			1  0  1  0  1
*/ 

#include<stdio.h>
main() 
{
    int rows, i, j, num;

    printf("\n\t --> Enter the number of rows : ");
    scanf("%d", &rows);

    for (i=1;i<=rows;++i)     // Loop to iteract through each row
	{
        num=1;

        for (j=1;j<=i;++j)         // Loop to print each number in the row
		{
            printf("%d ", num);
            num=1-num;
        }
        printf("\n");
    }
}
