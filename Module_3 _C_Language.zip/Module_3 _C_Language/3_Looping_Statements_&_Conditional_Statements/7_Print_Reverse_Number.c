/* 
7. WAP to print number in reverse order 
e.g.: number = 64728 ---> reverse = 82746.
*/

#include<stdio.h>
main()
{
    int number=64728, reverse=0;
    
    printf("\n\t Original number : | %d | \n", number);

    while (number!=0)     // Use a while loop to reverse the number
	{
        int digit=number%10;
        reverse=reverse*10+digit;
        number/=10;         // Remove the last digit from the original number
    }

    printf("\n\n\t --> Reversed number: %d\n", reverse);
}


