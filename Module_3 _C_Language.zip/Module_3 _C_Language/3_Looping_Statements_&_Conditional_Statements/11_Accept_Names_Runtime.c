// 11. Accept 5 names from user at run time.

#include<stdio.h>

main() 
{
    char *names[5]; 
    int i;

    printf("\n\t Enter 5 names : \n");
    for (i = 0; i < 5; ++i) {
        names[i] = (char *)malloc(50*sizeof(char));
        printf("\n\t Enter name ( %d ) : ", i+1);
        scanf(" %49[^\n]", names[i]); // Read up to 49 characters until newline
    }

    printf("\n------------------------------------------------\n");
    printf("\n\t *** Names entered : *** \n");
    for (i=0;i<5;++i)
        printf("\n\t --> ( %d ) . | %s | \n", i + 1, names[i]);

    for (i=0;i<5;++i)     // Free allocated memory
        free(names[i]); // Free memory allocated for each name
}

