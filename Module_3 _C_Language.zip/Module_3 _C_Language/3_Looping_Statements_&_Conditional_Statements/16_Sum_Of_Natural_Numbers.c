// 16. Calculate the Sum of Natural Numbers Using the While Loop.

#include<stdio.h>
main() 
{
    int p, n, sum = 0, i = 1,continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", p+1);
	p=p+1;

    printf("\n\n\t Enter a positive integer : ");
    scanf("%d", &n);

    while (i<=n)     // Calculate sum of natural numbers from 1 to n
	{
        sum+=i;
        i++;
    }

    printf("\n\n\t --> Sum of natural numbers from 1 to %d is : | %d | \n", n, sum);
    // Ask the user if they want to Check for another Sum of natural numbers from 1 to given number
    printf("\n *** Do you want to Check for another Sum of natural numbers from 1 to given number ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n-------------------------------------------------------------------------------------------------------------------------");
    }
}

