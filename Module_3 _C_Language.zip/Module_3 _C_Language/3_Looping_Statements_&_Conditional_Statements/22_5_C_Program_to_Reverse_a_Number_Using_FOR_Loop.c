/* 22_5. C Program to Reverse a Number Using FOR Loop
--> Series Program:
E. 1 2 3 6 9 18 27 54...
*/

#include<stdio.h>
main() 

{
    int term1=1, term2=2, nextTerm;
    
    printf("%d %d ", term1, term2);
    
    while (term1<=1000000000 && term2<=1000000000)     // Generate terms until one of them exceeds 1,00,00,00,000
	{
        nextTerm=term1+term2;         // Addition
        printf("%d ", nextTerm);
        
        term1=term2;         // Update terms
        term2=nextTerm;
        
        if (term1<=1000000000 && term2<=1000000000)         // Check if next term exceeds 1,00,00,00,000 before continuing
		{
            // Step 2: Multiplication
            nextTerm=term1*2;
            printf("%d ", nextTerm);
            
            // Update terms
            term1=term2;
            term2=nextTerm;
        }
    }  
    printf("\n --> Series generation completed. \n");
}
