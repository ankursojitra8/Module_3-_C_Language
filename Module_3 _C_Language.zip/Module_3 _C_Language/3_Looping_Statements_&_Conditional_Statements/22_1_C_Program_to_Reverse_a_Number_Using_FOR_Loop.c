/* 22. C Program to Reverse a Number Using FOR Loop
--> Series Program:
A. 1 + 2 + 3 + 4 + 5 + ... + n
*/

#include<stdio.h>
main()
{
    int n, i, sum=0;

    printf("\n\t Enter a positive integer : ");
    scanf("%d", &n);

    for (i=1;i<=n;++i)     // Calculation the sum of the series
        sum+=i;

    printf("\n\t --> Sum of the series from 1 to %d is :  | %d | \n", n, sum);
}

