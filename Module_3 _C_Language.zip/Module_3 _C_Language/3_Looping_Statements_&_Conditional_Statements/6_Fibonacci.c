// 6. WAP to print Fibonacci series up to given numbers.

#include<stdio.h>
main()
{
    int i, limit, first = 0, second = 1, p, next, continueCalculation = 1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", p+1);
	p=p+1;

    printf("\n\t Enter the limit up to which you want to print the Fibonacci series : ");
    scanf("%d", &limit);

    printf("\n\t Fibonacci series up to %d numbers : \n", limit);

    if (limit>=1)     // Print the first two numbers of the Fibonacci series
        printf("/n/t --> %d ", first);
        
    if (limit>=2)
        printf("/n/t --> %d ", second);

    for (i=3;i<=limit;++i)     // Print the rest of the Fibonacci series
	{
        next=first+second;
        printf("\n\t --> %d ",next);
        first=second;
        second=next;
    }
    printf("\n");
    // Ask the user if they want to Check for another units
    printf("\n *** Do you want to Check for another units ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

