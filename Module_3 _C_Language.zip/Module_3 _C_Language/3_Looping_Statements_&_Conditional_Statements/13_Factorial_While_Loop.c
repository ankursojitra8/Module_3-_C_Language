// 13. calculate the Factorial of a Given Number using while loop.

#include<stdio.h>
main()
{
    int i, number, factorial = 1, originalNumber, continueCalculation=1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", i+1);
	i=i+1;

    printf("\n\t Enter a number to calculate its factorial : ");
    scanf("%d", &number);

    originalNumber=number;     // Store original number for display purposes

    while (number>0)     // Calculate factorial using a while loop
	{
        factorial*=number;
        number--;
    }

    printf("\n\n\t --> Factorial of %d is : %d\n", originalNumber, factorial);
	
	// Ask the user if they want to Check for another units
    printf("\n *** Do you want to Check for another units ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}
