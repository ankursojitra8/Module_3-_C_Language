/* 18. Write a C Program to Print the Multiplication Table of N.
E.g. 
i. 5 * 1 = 5
ii. 5 * 2 = 10
1. .
2. .
iii. 5 * 10 = 50
*/

#include<stdio.h>
main()
{
    int p, N, i, continueCalculation=1;

    for (;continueCalculation=1;) 
	{
	printf("\n  |< %d >| \n", p+1);
	p=p+1;
    
    printf("\n\t Enter a number to print its multiplication table : ");
    scanf("%d", &N);
    
    printf("\n\n\t --> Multiplication Table of ( %d ) : \n", N);     // Print the multiplication table from 1 to 10
    for (i=1;i<=10;i++)
        printf("\t --> %d * %d = %d \n", N, i, N * i);
        
    // Ask the user if they want to perform another multiplication table
    printf("\n *** Do you want to perform another multiplication table ? Enter 1 for Yes, 0 for No: *** \n\n    --->>\t");
    scanf("%d", &continueCalculation);
    printf("\n------------------------------------------------------------------------------------------------");
    }
}

